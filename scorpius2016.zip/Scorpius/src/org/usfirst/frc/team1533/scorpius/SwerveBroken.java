package org.usfirst.frc.team1533.scorpius;

public class SwerveBroken {
	static boolean initSwerveBroken;
	
	public SwerveBroken(){
		
	}

}
