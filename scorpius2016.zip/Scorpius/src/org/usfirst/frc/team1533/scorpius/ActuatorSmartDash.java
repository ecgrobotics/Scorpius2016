package org.usfirst.frc.team1533.scorpius;

import edu.wpi.first.wpilibj.command.Subsystem;

public class ActuatorSmartDash extends Subsystem{

	@Override
	protected void initDefaultCommand() {
		// TODO Auto-generated method stub
		
		
	}

}
